<!DOCTYPE html>
    <html lang="ru">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title> GameMode | Support</title>
            <meta name="keywords" content="gamemode">
            <link rel="shortcut icon" href="storage/favicon.ico" type="image/x-icon">
            <link rel="stylesheet" href="css/style.css">
            <link rel="stylesheet" href="css/tippy.css">
            <meta name="author" content="mont1">
            <meta name="yandex-verification" content="7ffeec88f23edc0c" />
            <meta http-equiv="refresh" content="#">
            <meta http-equiv="Cache-Control" content="public">
            <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@400;500;700&amp;family=Roboto:wght@400;500;700&amp;display=swap" rel="stylesheet">
            <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
            <!-- flags -->
            <link rel="alternate" hreflang="ru-ru" href="http://localhost/gamemode.xyz/ru-ru/"/>
            <link rel="alternate" hreflang="en-us" href="http://localhost/gamemode.xyz/en-us/"/>
            <link rel="alternate" hreflang="x-default" href="http://localhost/gamemode.xyz/ru-ru/">
            <!-- end flags -->
            <!-- public -->
            <meta content="GameMode.xyz | КсГо Сервера | CSGO name="application-name">
            <meta content="GameMode - игровая сетка серверов CS:GO" name="description">
            <meta content="game,modee,gamemode.xyz,gamemode,modegame,гейминг" name="keywords">
            <!-- end  public -->
            <!-- jquery -->
            <script src="http://yandex.st/jquery/1.7.2/jquery.min.js"></script>
            <script src="js/arcticmodal/jquery.arcticmodal-0.1.min.js"></script>
            <link rel="stylesheet" href="js/arcticmodal/jquery.arcticmodal-0.1.css">
            <!-- end jquery -->
            <!-- script -->
            <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
            <script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=G-3YQRNP74J4&amp;l=dataLayer&amp;cx=c"></script>
            <script type="text/javascript" async="" src="https://vk.com/js/api/openapi.js?162"></script>
            <script src="https://unpkg.com/@popperjs/core@2"></script>
            <script src="https://unpkg.com/tippy.js@6"></script>
            <script src="js/app.js"></script>
            <!-- end script -->
</head>
<body>
    <div id="application">
    <header>
                <a href="home.php" class="logo" id="logo_button">GM</a>
                <ul>
                    <li><a href="home" id="home_button">Главная</a></li>
                    <li><a id="premium_pro" href="premium" disabled>PREMIUM Игроки</a></li>
                    <li><a href="learn" id="learn_button">FAQ</a></li>
                    <li><a href="support" id="support_button">Поддержка</a></li>
                </ul>
                <nav id="user">
                    <?php
                        require 'auth/steam/steamauth.php';
                        loginbutton();

                        if(isset($_COOKIE['steamai'])){
                            require 'auth/steam/userinfo.php';
                            echo $steamprofile['avatar'];
                            echo "<a href=auth/steam/logout.php>Выйти</a>";
                        }

                    ?>
                </nav>
            </header>
        <main>
            <div class="wrap">
                <div class="pages">
                   <div id="contact-form">
                    <div>
                        <h1 class="support-h1">Обратная связь</h1>
                        <p class="support-p">Пожалуйста, отправьте ваше сообщение. Мы свяжемся с вами в ближайшее время!</p>
                        <form class="support__form">
                            <label>
                                <img src="png/svg/person-outline.svg" alt>
                                <input id="contacts_fio" autofocus="" placeholder="Nick" required="">
                            </label>
                            <br>
                            <label>
                                <img src="png/svg/mail-outline.svg">
                                <input id="contacts_email" type="email" placeholder="Электронный адрес" required="">
                            </label>
                            <br>
                            <label>
                                <textarea id="contacts_message" placeholder="Ваше сообщение..."></textarea>
                            </label>
                            <br>
                            <a id="submit_feedback" class="btn">Отправить сообщение</a>
                        </form>
                    </div>
                </div>
            </div>
            <div class="footer">
                    <div id="foot">
                            <nav>
                                <a href="home">Домой</a>
                                <a href="premium">Premium</a>
                                <a href="support">Поддержка</a>
                                <a href="learn">FAQ</a>
                                <a href="https://app.gitbook.com/@onlyspring/s/gamemode-developer/~/drafts/-MI-zU0adI2ERBuesdN6/" target="_blank">Для Разработчиков</a>
                            </nav>
                        <p>Размещенная на настоящем сайте информация носит исключительно информационный характер и ни при каких условиях не является публичной офертой.</p>
                        <nav>
                            <a href="cookie">Политика конфиденциальности</a>
                        </nav>
                        <div class="wallet-block">
                            <div class="wallet-block-one">
                                <img class='wallet-block-img' loading="lazy" src="storage/webp/visa.webp" alt="Visa">
                            </div>
                            <div class="wallet-block-two">
                                <img class='wallet-block-img' loading="lazy" src="https://cybershoke.net/storage/images/global/1200px-Mastercard_2019_logo.svg.webp" alt="MasterCard">
                            </div>
                        </div>
                    </div>
        </main>
        <!-- <a id="cookie-policy" style="display: inline;">
                <span target="_blank" class="cookie-policy__container" onclick="document.location=`cookie`"><font color="#fff">Мы используем cookies для быстрой и удобной работы сайта. Продолжая пользоваться сайтом, вы принимаете условия пользовательского соглашения и политику конфиденциальности</font>
                <button onclick="">✕</button>
                </span>
        </a> -->
            <script src="https://unpkg.com/@popperjs/core@2"></script>
            <script src="https://unpkg.com/tippy.js@6"></script>
            <script src="js/app.js"></script>
            <script src="js/iziToast.min.js"></script>
        </body>
    </html>
