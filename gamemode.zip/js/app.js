tippy('#myButton1', {
    content: "Войти в профиль?",
    animations: "shift-toward-subtle",
    arrow: false,
  });
  tippy('#home_button', {
    content: "Главная",
    animations: "shift-toward-subtle",
    arrow: false,
  });
  tippy('#learn_button', {
    content: "FAQ",
    animations: "shift-toward-subtle",
    arrow: false,
  });
  tippy('#support_button', {
    content: "Поддержка",
    animations: "shift-toward-subtle",
    arrow: false,
  });
    tippy('#myButton7', {
    content: "Выход",
    animations: "shift-toward-subtle",
    arrow: false,
  });

  // window.addEventListener("scroll", function(){
  //   var header = document.querySelector("header");
  //     header.classList.toggle("sticky", window.scrollY > 0);
  // })
  tippy('#logo_button', {
    content: "Домой",
    animations: "shift-toward-subtle",
    arrow: false,
    theme: 'light',
  });
    tippy('#myButton8', {
    content: "Новости",
    animations: "shift-toward-subtle",
    arrow: false,
    theme: 'light',
  });
  tippy('#premium_pro', {
    content: "Premium-Игроки",
    animations: "shift-toward-subtle",
    arrow: false,
  });
  $(document).ready(function(){
    iziToast.info({
      id:'info',
      title: 'Ой что-то пошло не так! Код Ошибки 0x130843',
      position: 'topLeft',
      color: '#d49297',
      class: '#submit_feedback',
    });
  });
$('#exampleModal1').arcticmodal();
